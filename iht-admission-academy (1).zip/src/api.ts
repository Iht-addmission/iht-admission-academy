/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { auth, db } from './lib/firebase';
import { 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';

// Helper to convert Firestore timestamp to ISO string
const toISO = (ts: any) => {
  if (ts instanceof Timestamp) return ts.toDate().toISOString();
  return ts || new Date().toISOString();
};

export async function fetchNotices() {
  const q = query(collection(db, 'notices'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), date: toISO(doc.data().createdAt) }));
}

export async function createNotice(data: any) {
  const docRef = await addDoc(collection(db, 'notices'), {
    ...data,
    createdAt: serverTimestamp()
  });
  return { id: docRef.id, ...data };
}

export async function deleteNotice(id: string) {
  await deleteDoc(doc(db, 'notices', id));
}

export async function fetchAbout() {
  const docSnap = await getDoc(doc(db, 'settings', 'about'));
  if (docSnap.exists()) return docSnap.data();
  // Fallback to default
  return {
    ownerName: 'MD SHARIF ISLAM JOY',
    designation: 'Founder & Academic Director',
    qualification: 'On-going students, DMT in health Technology(ICA), BSc in Health Technology (DU)',
    bio: 'Leading the frontier of medical technical education for over a decade. Our mission is to produce world-class clinical technicians for Bangladesh.',
    vision: 'To harmonize technological precision with humanitarian medical care.',
    phone: '01819248542',
    email: 'xoysharif@gmail.com',
    photoUrl: '/src/assets/images/regenerated_image_1777971748339.jpg',
  };
}

export async function updateAbout(data: any) {
  await setDoc(doc(db, 'settings', 'about'), data, { merge: true });
  return data;
}

export async function submitAdmission(data: any) {
  const docRef = await addDoc(collection(db, 'admissions'), {
    ...data,
    status: 'pending',
    createdAt: serverTimestamp()
  });
  return { id: docRef.id, ...data, status: 'pending' };
}

export async function fetchAdmissions() {
  const q = query(collection(db, 'admissions'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ 
    id: doc.id, 
    ...doc.data(), 
    submittedAt: toISO(doc.data().createdAt) 
  }));
}

export async function updateAdmissionStatus(id: string, status: string) {
  const admissionRef = doc(db, 'admissions', id);
  await updateDoc(admissionRef, { status });
  
  if (status === 'approved') {
    const admissionSnap = await getDoc(admissionRef);
    if (admissionSnap.exists()) {
      const admissionData = admissionSnap.data();
      const userId = admissionData.userId;
      if (userId) {
        await updateDoc(doc(db, 'users', userId), { isPaid: true });
      }
    }
  }
  
  return { id, status };
}

export async function seedDatabase() {
  console.log('Starting global database seeding...');
  const institutes = [
    { name: 'Dhaka Medical College (IHT)', address: 'Dhaka', photo: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=2053&auto=format&fit=crop', level: '100th+', rating: '4.9', description: 'Premier medical institution in Bangladesh for technical excellence.', seats: {} },
    { name: 'Rajshahi Medical College (IHT)', address: 'Rajshahi', photo: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=2070&auto=format&fit=crop', level: '150th+', rating: '4.8', description: 'Leading healthcare and education center in North Bengal.', seats: {} }
  ];
  
  const notices = [
    { title: 'Admission Open 2024-25 Session', content: 'Admission is now officially open for DMT, Pharmacy, and Radiology.', date: new Date().toISOString(), type: 'admission' },
    { title: 'Academic Calendar Published', content: 'The full academic calendar for the current session is now available.', date: new Date().toISOString(), type: 'academic' }
  ];

  const courses = [
    { title: 'DMT (Diploma in Medical Technology)', price: '12,500', fee: 12500, duration: '3 Years', seats: '50', students: '1.2k', rating: '4.9', instructor: 'Dr. Sharif Ahmed', level: 'Diploma', description: 'Advanced diploma in pathology, hematology and biochemistry.', syllabus: ['Hematology', 'Biochemistry', 'Microbiology'] },
    { title: 'DPT (Diploma in Pharmacy)', price: '15,000', fee: 15000, duration: '3 Years', seats: '40', students: '800', rating: '4.8', instructor: 'Prof. Hasan Ali', level: 'Diploma', description: 'Pharmaceutical sciences and pharmacology.', syllabus: ['Pharmacology', 'Physiology', 'Medicines'] },
    { title: 'Admission Masterclass', price: '4,500', fee: 4500, duration: '6 Months', seats: '200', students: '5k', rating: '5.0', instructor: 'Joy Sharif', level: 'Admission', description: 'Complete preparation for Govt IHT/MATS admission exams.', syllabus: ['Biology', 'Chemistry', 'Physics', 'General Knowledge'] }
  ];

  try {
    // Seed Institutes
    for (const inst of institutes) {
      await addDoc(collection(db, 'institutes'), inst);
    }

    // Seed Notices
    for (const notice of notices) {
      await addDoc(collection(db, 'notices'), notice);
    }

    // Seed Courses
    for (const course of courses) {
      await addDoc(collection(db, 'courses'), course);
    }
    console.log('Database seeded successfully.');
    return { success: true };
  } catch (error) {
    console.error('Seeding failed:', error);
    throw error;
  }
}

export async function fetchAdmissionStatus(email: string) {
  const q = query(collection(db, 'admissions'), where('email', '==', email), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  if (snapshot.empty) return null;
  const data = snapshot.docs[0].data();
  return { id: snapshot.docs[0].id, ...data, submittedAt: toISO(data.createdAt) };
}

export async function fetchCourses() {
  const snapshot = await getDocs(collection(db, 'courses'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function createCourse(data: any) {
  const docRef = await addDoc(collection(db, 'courses'), data);
  return { id: docRef.id, ...data };
}

export async function updateCourse(id: string, data: any) {
  await updateDoc(doc(db, 'courses', id), data);
  return { id, ...data };
}

export async function deleteCourse(id: string) {
  await deleteDoc(doc(db, 'courses', id));
}

export async function fetchTeachers() {
  const q = query(collection(db, 'users'), where('role', '==', 'teacher'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function createTeacher(data: any) {
  // Ideally this should be handled by a secure function, but for now we create the user doc
  const docRef = await addDoc(collection(db, 'users'), { ...data, role: 'teacher' });
  return { id: docRef.id, ...data, role: 'teacher' };
}

export async function updateTeacher(id: string, data: any) {
  await updateDoc(doc(db, 'users', id), data);
  return { id, ...data };
}

export async function deleteTeacher(id: string) {
  await deleteDoc(doc(db, 'users', id));
}

export async function loginWithGoogle() {
  const provider = new GoogleAuthProvider();
  const userCredential = await signInWithPopup(auth, provider);
  const fbUser = userCredential.user;

  const userRef = doc(db, 'users', fbUser.uid);
  const userDoc = await getDoc(userRef);
  
  const isAdmin = fbUser.email === 'xoysharif@gmail.com';

  if (userDoc.exists()) {
    const data = userDoc.data();
    if (isAdmin && (data.role !== 'admin' || data.isPaid !== true)) {
       await setDoc(userRef, { ...data, role: 'admin', isPaid: true }, { merge: true });
       return { id: fbUser.uid, email: fbUser.email, ...data, role: 'admin', isPaid: true };
    }
    return { id: fbUser.uid, email: fbUser.email || '', ...data };
  }

  const userData = {
    uid: fbUser.uid,
    email: fbUser.email,
    displayName: fbUser.displayName || '',
    role: isAdmin ? 'admin' : 'student',
    isPaid: isAdmin ? true : false,
    createdAt: new Date().toISOString()
  };

  await setDoc(userRef, userData);
  return { id: fbUser.uid, ...userData };
}

export async function login(credentials: any) {
  const { email, password } = credentials;
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  const fbUser = userCredential.user;
  
  const userRef = doc(db, 'users', fbUser.uid);
  const userDoc = await getDoc(userRef);
  
  const isAdmin = fbUser.email === 'xoysharif@gmail.com';

  if (userDoc.exists()) {
    const data = userDoc.data();
    if (isAdmin && (data.role !== 'admin' || data.isPaid !== true)) {
       await setDoc(userRef, { ...data, role: 'admin', isPaid: true }, { merge: true });
       return { id: fbUser.uid, email: fbUser.email, ...data, role: 'admin', isPaid: true };
    }
    return { id: fbUser.uid, email: fbUser.email || '', ...data };
  }
  
  const userData = {
    uid: fbUser.uid,
    email: fbUser.email,
    displayName: fbUser.displayName || '',
    role: isAdmin ? 'admin' : 'student',
    isPaid: isAdmin ? true : false,
    createdAt: new Date().toISOString()
  };
  
  await setDoc(userRef, userData);
  return { id: fbUser.uid, ...userData };
}

export async function signup(data: any) {
  const { email, password, name } = data;
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  const fbUser = userCredential.user;

  await updateProfile(fbUser, { displayName: name });

  const isAdmin = email === 'xoysharif@gmail.com';
  const userData = {
    uid: fbUser.uid,
    email: fbUser.email,
    displayName: name,
    role: isAdmin ? 'admin' : 'student',
    isPaid: isAdmin ? true : false,
    createdAt: new Date().toISOString()
  };

  await setDoc(doc(db, 'users', fbUser.uid), userData);
  return { id: fbUser.uid, ...userData };
}

export async function fetchInstitutes() {
  const snapshot = await getDocs(collection(db, 'institutes'));
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function addInstitute(data: any) {
  const docRef = await addDoc(collection(db, 'institutes'), data);
  return { id: docRef.id, ...data };
}

export async function updateInstitute(id: string, data: any) {
  await updateDoc(doc(db, 'institutes', id), data);
  return { id, ...data };
}

export async function deleteInstitute(id: string) {
  await deleteDoc(doc(db, 'institutes', id));
}

export async function fetchExams() {
  const q = query(collection(db, 'exams'), where('status', '==', 'active'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function createExam(data: any) {
  const docRef = await addDoc(collection(db, 'exams'), {
    ...data,
    createdAt: serverTimestamp()
  });
  return { id: docRef.id, ...data };
}

export async function submitExamResult(data: any) {
  const docRef = await addDoc(collection(db, 'examResults'), {
    ...data,
    submittedAt: serverTimestamp()
  });
  return { id: docRef.id, ...data };
}

export async function fetchExamResults(email: string) {
  const q = query(collection(db, 'examResults'), where('userEmail', '==', email), orderBy('submittedAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), submittedAt: toISO(doc.data().submittedAt) }));
}

export async function fetchAllExamResults() {
  const q = query(collection(db, 'examResults'), orderBy('submittedAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data(), submittedAt: toISO(doc.data().submittedAt) }));
}
