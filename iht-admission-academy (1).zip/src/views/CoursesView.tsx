/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import { Clock, DollarSign, GraduationCap, Check, ArrowRight, User, Award, ListChecks, ChevronDown, ChevronUp, Users, Target, Briefcase, ShieldCheck, BookOpen, Microscope, Activity, Scan, HeartPulse, Smile, Pill, Scissors } from 'lucide-react';
import { COURSES } from '../constants';
import { useState } from 'react';

interface CoursesViewProps {
  onNavigate: (page: string, courseId?: string) => void;
}

export default function CoursesView({ onNavigate }: CoursesViewProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="pt-32 pb-24 bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-6 border border-blue-100"
          >
            <Award size={14} /> State Medical Faculty of Bangladesh
          </motion.div>
          <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight">Diploma in Medical Technology <span className="text-blue-600">(DMT)</span></h1>
          <p className="text-slate-500 italic max-w-3xl mx-auto leading-relaxed text-sm md:text-base">
            Professional healthcare career pathways approved by the Ministry of Health and Family Welfare. 
            All courses follow the official syllabus for comprehensive technical medical education.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {COURSES.map((course, i) => (
            <motion.div 
              key={course.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="group bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-blue-100/50 transition-all duration-500 flex flex-col h-full overflow-hidden"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={course.image} 
                  alt={course.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex items-end p-8">
                   <div className="text-white">
                      <div className="text-[9px] font-black uppercase tracking-widest bg-blue-600 px-2 py-0.5 rounded w-fit mb-2">SMF Approved</div>
                      <h2 className="text-lg font-black leading-tight uppercase tracking-tight">{course.title}</h2>
                   </div>
                </div>
                {course.logo && (
                  <div className="absolute top-6 right-6 w-14 h-14 bg-white/90 backdrop-blur-sm rounded-2xl p-2.5 flex items-center justify-center border border-white/20 shadow-xl z-20">
                    <img 
                      src={course.logo} 
                      alt={`${course.title} icon`} 
                      className="w-full h-full object-contain grayscale-0 group-hover:scale-110 transition-transform"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
              </div>

              <div className="p-8 flex flex-col flex-1">
                <div className="flex flex-wrap gap-2 mb-6">
                  <div className="bg-slate-50 text-slate-500 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 border border-slate-100">
                    <Clock size={12} /> {course.duration}
                  </div>
                  <div className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 border border-blue-100">
                    <GraduationCap size={12} /> {course.qualification}
                  </div>
                </div>

                <p className="text-slate-600 text-sm mb-6 leading-relaxed font-medium">
                  {course.description}
                </p>

                <div className="mt-auto space-y-6">
                  <div className="space-y-3">
                     <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1">Career Opportunities</h4>
                     <div className="flex flex-wrap gap-1.5">
                       {course.jobFacilities?.slice(0, 3).map((job, idx) => (
                         <span key={idx} className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-md text-[10px] font-bold border border-emerald-100/50">{job}</span>
                       ))}
                     </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-slate-50">
                     <button 
                       onClick={() => onNavigate('course-detail', course.id)}
                       className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-blue-600 transition-all shadow-xl shadow-slate-100 active:scale-95 flex items-center justify-center gap-2"
                     >
                       Apply Now <ArrowRight size={14} />
                     </button>
                     <button 
                       onClick={() => toggleExpand(course.id)}
                       className="flex-1 bg-slate-50 text-slate-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-slate-100 transition-all border border-slate-100 flex items-center justify-center gap-2"
                     >
                       {expandedId === course.id ? 'Hide Specs' : 'View Specs'}
                       {expandedId === course.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                     </button>
                  </div>
                </div>
              </div>

              <AnimatePresence>
                {expandedId === course.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-slate-50 border-t border-slate-100"
                  >
                    <div className="p-8 space-y-6">
                       <div className="grid grid-cols-2 gap-4">
                          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                             <div className="text-[9px] text-slate-400 font-black uppercase mb-1">Total Seats</div>
                             <div className="text-lg font-black text-slate-900">{course.totalSeats}</div>
                          </div>
                          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                             <div className="text-[9px] text-slate-400 font-black uppercase mb-1">Target Mark</div>
                             <div className="text-lg font-black text-blue-600">{course.cutMark}</div>
                          </div>
                       </div>

                       <div className="space-y-3">
                          <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2 italic">
                            Official SMF Notice: Course length inclusive of 1-year mandatory clinical internship.
                          </h4>
                       </div>

                       <div className="pt-6 border-t border-slate-200">
                          <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                            <ShieldCheck size={14} className="text-blue-600" />
                            Official Association & Affiliation
                          </h4>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                             <div className="space-y-5">
                                <div>
                                   <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Accreditation Status</div>
                                   <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-xl text-[10px] font-black border border-emerald-100 shadow-sm">
                                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                                      {course.accreditationStatus}
                                   </div>
                                </div>
                                <div>
                                   <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Affiliation Authority</div>
                                   <div className="flex flex-wrap gap-2">
                                      {course.affiliationAuthority?.map((auth, idx) => (
                                        <div key={idx} className="flex items-center gap-1.5 bg-slate-900 text-white px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider">
                                           <Award size={10} className="text-blue-400" />
                                           {auth}
                                        </div>
                                      ))}
                                   </div>
                                </div>
                             </div>

                             <div className="space-y-5">
                                <div>
                                   <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Professional Associations</div>
                                   <div className="flex flex-wrap gap-2">
                                      {course.professionalAssociations?.map((assoc, idx) => (
                                        <div key={idx} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-[9px] font-bold border border-blue-100 flex items-center gap-1.5">
                                           <Users size={10} />
                                           {assoc}
                                        </div>
                                      ))}
                                   </div>
                                </div>
                                <div>
                                   <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Clinical Training Partners</div>
                                   <div className="flex flex-wrap gap-2">
                                      {course.clinicalPartners?.map((partner, idx) => (
                                        <div key={idx} className="bg-orange-50 text-orange-700 px-3 py-1 rounded-lg text-[9px] font-bold border border-orange-100 flex items-center gap-1.5">
                                           <Microscope size={10} />
                                           {partner}
                                        </div>
                                      ))}
                                   </div>
                                </div>
                             </div>
                          </div>
                          
                          <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col items-center gap-2">
                             <p className="text-[9px] text-slate-400 font-medium italic leading-relaxed text-center px-4">
                                "All affiliations are based on publicly available and officially recognized sources. Information may vary by institute."
                             </p>
                             <div className="flex gap-4 opacity-30 grayscale scale-75">
                               <img src="https://upload.wikimedia.org/wikipedia/commons/8/84/Government_Seal_of_Bangladesh.svg" alt="SMF" className="h-6" referrerPolicy="no-referrer" />
                             </div>
                          </div>
                       </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-24 p-8 md:p-12 bg-white rounded-[3rem] border border-blue-100 shadow-2xl shadow-blue-50 text-center relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Award size={200} />
          </div>
          <div className="relative z-10">
            <div className="w-20 h-20 bg-blue-600 text-white rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-blue-200 -rotate-6">
               <ShieldCheck size={40} />
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-6 uppercase tracking-tight">Official Accreditation Note</h2>
            <p className="text-slate-600 max-w-4xl mx-auto leading-relaxed font-medium italic">
              "All courses detailed above are strictly conducted under the academic supervision of the <span className="text-blue-600 font-black">State Medical Faculty of Bangladesh (SMF)</span> and are duly approved by the <span className="text-slate-900 font-black">Ministry of Health and Family Welfare</span>. Graduates are eligible for government registration and private practice as skilled Medical Technologists across all healthcare sectors."
            </p>
            <div className="mt-10 flex items-center justify-center gap-6 grayscale opacity-50">
               <img src="https://upload.wikimedia.org/wikipedia/commons/8/84/Government_Seal_of_Bangladesh.svg" alt="Govt Logo" className="h-16" referrerPolicy="no-referrer" />
               <div className="w-px h-12 bg-slate-200"></div>
               <div className="text-left">
                  <div className="text-[10px] font-black text-slate-900 uppercase">Directorate General of</div>
                  <div className="text-[10px] font-black text-slate-900 uppercase">Health Services (DGHS)</div>
               </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
